/**
 * app.js - Punto de entrada principal de la aplicación Express
 *
 * Aquí se crea y configura la instancia de Express:
 *  - Se aplican middlewares globales (como el parser de JSON)
 *  - Se montan las rutas bajo sus prefijos correspondientes
 *  - Se inicia el servidor en un puerto determinado
 */

// Importamos Express, el framework que nos permite crear el servidor HTTP
const express = require("express");

// Importamos los routers de cada recurso
const usuariosRouter = require("./routes/usuarios.routes");
const productosRouter = require("./routes/productos.routes");

// Creamos la aplicación Express.
// "app" es el objeto central: representa nuestro servidor.
const app = express();

// ─────────────────────────────────────────
// MIDDLEWARES GLOBALES
// ─────────────────────────────────────────
// Un middleware es una función que se ejecuta ENTRE que llega la request
// y que se envía la response. Express los procesa en orden, de arriba a abajo.

// express.json() parsea el body de las peticiones con Content-Type: application/json
// Sin esto, req.body sería undefined al recibir JSON.
app.use(express.json());

// express.urlencoded() parsea datos enviados desde formularios HTML
// (Content-Type: application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Middleware de logging casero: imprime método y URL de cada petición
// Esto ilustra cómo funciona un middleware: recibe (req, res, next)
// y llama a next() para pasar al siguiente middleware o ruta.
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next(); // Sin next(), la petición quedaría "colgada"
});

// ─────────────────────────────────────────
// RUTAS
// ─────────────────────────────────────────
// Montamos los routers bajo sus prefijos.
// Cualquier petición que empiece con /api/usuarios será manejada por usuariosRouter.
app.use("/api/usuarios", usuariosRouter);
app.use("/api/productos", productosRouter);

// Ruta raíz de bienvenida
app.get("/", (req, res) => {
  res.json({
    mensaje: "Bienvenido al proyecto de repaso de Express.js 🚀",
    rutas_disponibles: [
      "GET    /api/usuarios",
      "GET    /api/usuarios/:id",
      "POST   /api/usuarios",
      "PUT    /api/usuarios/:id",
      "DELETE /api/usuarios/:id",
      "GET    /api/productos",
      "GET    /api/productos/:id",
      "GET    /api/productos/categoria/:categoria",
      "POST   /api/productos",
      "PUT    /api/productos/:id",
      "DELETE /api/productos/:id",
    ],
  });
});

// Middleware 404: se ejecuta si ninguna ruta anterior coincidió
app.use((req, res) => {
  res.status(404).json({ error: "Ruta no encontrada" });
});

// ─────────────────────────────────────────
// INICIO DEL SERVIDOR
// ─────────────────────────────────────────
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
  console.log(`📖 Endpoints disponibles en http://localhost:${PORT}/`);
});

module.exports = app; // Exportamos para posibles tests
