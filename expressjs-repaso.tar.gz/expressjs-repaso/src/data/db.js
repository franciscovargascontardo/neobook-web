/**
 * db.js - Base de datos en memoria
 *
 * Como no usamos una base de datos real, almacenamos los datos
 * en arrays de JavaScript. Estos datos se pierden al reiniciar el servidor,
 * pero son perfectos para practicar la lógica de una API REST.
 *
 * Exportamos los arrays para que los controladores puedan leerlos y modificarlos.
 */

// Array de usuarios en memoria
const usuarios = [
  { id: 1, nombre: "Ana García", email: "ana@ejemplo.com", rol: "admin" },
  { id: 2, nombre: "Carlos López", email: "carlos@ejemplo.com", rol: "user" },
  { id: 3, nombre: "María Martínez", email: "maria@ejemplo.com", rol: "user" },
];

// Array de productos en memoria
const productos = [
  {
    id: 1,
    nombre: "Laptop Pro",
    precio: 1200,
    categoria: "tecnologia",
    stock: 10,
  },
  {
    id: 2,
    nombre: "Teclado Mecánico",
    precio: 150,
    categoria: "tecnologia",
    stock: 25,
  },
  {
    id: 3,
    nombre: "Escritorio Roble",
    precio: 400,
    categoria: "muebles",
    stock: 5,
  },
  {
    id: 4,
    nombre: "Silla Ergonómica",
    precio: 350,
    categoria: "muebles",
    stock: 8,
  },
];

// Contadores de IDs para simular el auto-increment de una BD
// Cada vez que se crea un recurso, se incrementa el contador
let nextUsuarioId = 4;
let nextProductoId = 5;

module.exports = {
  usuarios,
  productos,
  // Funciones helper para obtener y avanzar el ID
  getNextUsuarioId: () => nextUsuarioId++,
  getNextProductoId: () => nextProductoId++,
};
