/**
 * productos.routes.js - Router de Productos
 *
 * Similar al de usuarios, pero incluye una ruta extra:
 * GET /categoria/:categoria → filtra productos por categoría usando un param de texto.
 *
 * ⚠️ ORDEN IMPORTA: Express evalúa las rutas de arriba a abajo.
 * La ruta /categoria/:categoria DEBE ir antes de /:id,
 * porque si fuera al revés, Express interpretaría "categoria"
 * como el valor del parámetro :id.
 */

const { Router } = require("express");

const {
  obtenerProductos,
  obtenerProductoPorId,
  obtenerPorCategoria,
  crearProducto,
  actualizarProducto,
  eliminarProducto,
} = require("../controllers/productos.controller");

const router = Router();

// GET  /api/productos                        → todos (acepta ?precioMin y ?precioMax)
// POST /api/productos                        → crear producto (body: nombre, precio, categoria, stock)
router.get("/", obtenerProductos);
router.post("/", crearProducto);

// GET /api/productos/categoria/:categoria    → filtrar por categoría (param de texto)
// Esta ruta debe ir ANTES de /:id para evitar conflictos de parsing
router.get("/categoria/:categoria", obtenerPorCategoria);

// GET    /api/productos/:id                  → obtener por ID
// PUT    /api/productos/:id                  → actualizar por ID
// DELETE /api/productos/:id                  → eliminar por ID
router.get("/:id", obtenerProductoPorId);
router.put("/:id", actualizarProducto);
router.delete("/:id", eliminarProducto);

module.exports = router;
