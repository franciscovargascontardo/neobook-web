/**
 * productos.controller.js - Controlador de Productos
 *
 * Igual que el de usuarios, pero con un ejemplo adicional:
 * una ruta que filtra por un param de la URL (no query string).
 * Ejemplo: GET /api/productos/categoria/tecnologia
 */

const db = require("../data/db");

// GET /api/productos  →  todos los productos, con filtro opcional por query param
const obtenerProductos = (req, res) => {
  // req.query.precioMax vendría de: GET /api/productos?precioMax=500
  const { precioMax, precioMin } = req.query;

  let resultado = [...db.productos]; // Copia del array para no mutar el original

  if (precioMin) {
    resultado = resultado.filter((p) => p.precio >= Number(precioMin));
  }
  if (precioMax) {
    resultado = resultado.filter((p) => p.precio <= Number(precioMax));
  }

  res.json({ total: resultado.length, productos: resultado });
};

// GET /api/productos/:id  →  un producto por ID (param de URL)
const obtenerProductoPorId = (req, res) => {
  const id = Number(req.params.id);
  const producto = db.productos.find((p) => p.id === id);

  if (!producto) {
    return res
      .status(404)
      .json({ error: `Producto con id ${id} no encontrado` });
  }

  res.json(producto);
};

// GET /api/productos/categoria/:categoria
// Ejemplo de param de URL que NO es un ID numérico
// Importante: esta ruta debe definirse ANTES de /:id en el router
// para que Express no interprete "categoria" como un id.
const obtenerPorCategoria = (req, res) => {
  const { categoria } = req.params; // req.params.categoria = "tecnologia" (por ejemplo)

  const resultado = db.productos.filter(
    (p) => p.categoria.toLowerCase() === categoria.toLowerCase()
  );

  if (resultado.length === 0) {
    return res
      .status(404)
      .json({ error: `No se encontraron productos en la categoría '${categoria}'` });
  }

  res.json({ total: resultado.length, categoria, productos: resultado });
};

// POST /api/productos  →  crea un producto (datos desde el body)
const crearProducto = (req, res) => {
  const { nombre, precio, categoria, stock } = req.body;

  // Validación
  if (!nombre || precio === undefined || !categoria) {
    return res.status(400).json({
      error: "Los campos 'nombre', 'precio' y 'categoria' son obligatorios",
    });
  }

  if (typeof precio !== "number" || precio < 0) {
    return res.status(400).json({ error: "'precio' debe ser un número positivo" });
  }

  const nuevoProducto = {
    id: db.getNextProductoId(),
    nombre,
    precio,
    categoria,
    stock: stock ?? 0, // ?? = nullish coalescing: usa 0 si stock es null o undefined
  };

  db.productos.push(nuevoProducto);
  res.status(201).json(nuevoProducto);
};

// PUT /api/productos/:id  →  actualiza un producto (param de URL + body)
const actualizarProducto = (req, res) => {
  const id = Number(req.params.id);
  const { nombre, precio, categoria, stock } = req.body;

  const index = db.productos.findIndex((p) => p.id === id);

  if (index === -1) {
    return res
      .status(404)
      .json({ error: `Producto con id ${id} no encontrado` });
  }

  // Validación de precio si se envía
  if (precio !== undefined && (typeof precio !== "number" || precio < 0)) {
    return res.status(400).json({ error: "'precio' debe ser un número positivo" });
  }

  const productoActualizado = {
    ...db.productos[index],
    ...(nombre !== undefined && { nombre }),
    ...(precio !== undefined && { precio }),
    ...(categoria !== undefined && { categoria }),
    ...(stock !== undefined && { stock }),
  };

  db.productos[index] = productoActualizado;
  res.json(productoActualizado);
};

// DELETE /api/productos/:id
const eliminarProducto = (req, res) => {
  const id = Number(req.params.id);
  const index = db.productos.findIndex((p) => p.id === id);

  if (index === -1) {
    return res
      .status(404)
      .json({ error: `Producto con id ${id} no encontrado` });
  }

  const [eliminado] = db.productos.splice(index, 1);
  res.json({ mensaje: "Producto eliminado correctamente", producto: eliminado });
};

module.exports = {
  obtenerProductos,
  obtenerProductoPorId,
  obtenerPorCategoria,
  crearProducto,
  actualizarProducto,
  eliminarProducto,
};
